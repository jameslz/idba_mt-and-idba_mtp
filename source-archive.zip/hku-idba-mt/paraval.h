#ifndef PARAVAL_H
#define PARAVAL_H
#include "libheader.h"

class ParaVal {
public:
  ParaVal(int _index, char* _str_val, int _int_val):
  index(_index),
  str_val(_str_val),
  int_val(_int_val){};
  
  ~ParaVal(){
    if(str_val!=NULL)
      delete str_val;
  }
  
  int getIndex(){
    return index;
  }
  
  const char* getStrVal(){
    return str_val;
  }
  
  int getIntVal(){
    return int_val;
  }
  
private:
  int index;
  char* str_val;
  int int_val;
};

#endif
