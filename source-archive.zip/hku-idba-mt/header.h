#ifndef HEADER_H
#define HEADER_H

#include "dna.h"
#include "motif.h"
#include "neighbor.h"
#include "bindSite.h"
#include "tools.h"

#endif
