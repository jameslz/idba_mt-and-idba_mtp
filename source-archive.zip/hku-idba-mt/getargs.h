#ifndef GETARGS_H
#define GETARGS_H
#include "libheader.h"
#include "paraval.h"

struct ParaFormat {  
  int index;		//index of parameters
  const char* name;		//Name of parameters
  const char* desc;		//Description of parameters
  const char* symbol;		//Short symbol representation of the parameters
  int arg_no;		//number of argument (0 or 1)
  char arg_type;	//type of argument (d or s)
};

class Getargs {
public:
  Getargs(int argc, const char** argv
          , ParaFormat* para_format, int format_no);		//constructor

  ~Getargs();		//destructor

/*****************************************************************************/
/*                                                                           */
/* Pub 1 Access Attributes                                                   */
/*                                                                           */
/*****************************************************************************/

  bool isError();
  unsigned int getParaValSize();
  ParaVal* getPara(int i);

/*****************************************************************************/
/*                                                                           */
/* Pub 2 Algorithms                                                          */
/*                                                                           */
/*****************************************************************************/  

  void print_list (ostream &os);

private:

/*****************************************************************************/
/*                                                                           */
/* Pri 2 Parameters                                                          */
/*                                                                           */
/*****************************************************************************/
  bool is_error;
  vector<ParaVal*> para_vec;
  char* prog_name;
  ParaFormat* para_format;
  int para_size;
};

#endif
