#ifndef DNA_H
#define DNA_H
#include "libheader.h"

class DNA {
public:
  DNA(const char* name, const char* sequence);	//constructor
  ~DNA();					//destructor
  
/*****************************************************************************/
/*                                                                           */
/* Pub 1 Access Attributes                                                   */
/*                                                                           */
/*****************************************************************************/

  //get the name of the dna
  const char *getName();
  //get the DNA Sequence
  const char *getSeq();
  //get the reverse complement DNA Sequence
  const char *getSeqR();
  //get short representation
  const unsigned short *getShortRep();
  //get sequence length
  const int getSeqLength();
  //get k-mer size
  const int getKSize();
  //get k-mer representation
  const unsigned long* getkRep();
  
/*****************************************************************************/
/*                                                                           */
/* Pub 2 Algorithms                                                          */
/*                                                                           */
/*****************************************************************************/
  //create k-mer reprsentation
  int createKRep(int k_len);
  
/*****************************************************************************/
/*                                                                           */
/* Pub 3 Parameters                                                          */
/*                                                                           */
/*****************************************************************************/  
  
private:
/*****************************************************************************/
/*                                                                           */
/* Pri 1 Algorithms                                                          */
/*                                                                           */
/*****************************************************************************/

  //create integer representation of the DNA sequence
  void createShortRep();
  //create reverse complement of the DNA sequence
  void creatReverseComp();
  
  //encode DNA into k-mer integer
  unsigned long encode1(const unsigned short* seq, int k_length);
  unsigned long encode2(const unsigned short* seq, int k_length);
  
/*****************************************************************************/
/*                                                                           */
/* Pri 2 Parameters                                                          */
/*                                                                           */
/*****************************************************************************/
  const char* dnaName;
  const char* dnaSeq;
  char* dnaSeqR;
  unsigned short* shortRep;	//0,1,2,3 represents A,C,G,T
  unsigned long* kRep;		//represent each k_mer by 64-bit string
  int seqLength;
  int k_size;
};

#endif

