#include "contig.h"
#include "libheader.h"

/*****************************************************************************/
/*                                                                           */
/* Constructor and Destructor                                                */
/*                                                                           */
/*****************************************************************************/
Contig::Contig(){
  this->pattern=NULL;
  this->contig_len=0;
}


Contig::~Contig(){
  if(this->pattern!=NULL){
    delete this->pattern;
  }
}

/*****************************************************************************/
/*                                                                           */
/* Pub 1 Access Attributes                                                   */
/*                                                                           */
/*****************************************************************************/

//get pattern
const char* Contig::getSeq(){
  return this->pattern;
}
  
//set pattern
int Contig::setSeq(const char* pattern){
  if(this->pattern!=NULL){
    delete this->pattern;
  }
  this->pattern=pattern;
  this->contig_len=strlen(pattern);
  //this->start_code=KMer::PattoCode();
  
  return 0;
}

//get DNA sequence length
int Contig::getSeqLength(){
  return contig_len;
}

/*
//getCode
uint64_t Contig::getStartCode(){
  return start_code;
}
uint64_t Contig::getStartCodeR(){
  return start_codeR;
}
uint64_t Contig::getEndCode(){
  return end_code;
}
uint64_t Contig::getEndCodeR(){
  return end_codeR;
}
*/

//add neighbor read
int Contig::addNeigRead(int read_no){
  local_read_vec.push_back(read_no);
  return 0;
}

vector<int>* Contig::getNeigVec(){
  return &local_read_vec;
}
/*****************************************************************************/
/*                                                                           */
/* Pub 2 Algorithms                                                          */
/*                                                                           */
/*****************************************************************************/




/*****************************************************************************/
/*                                                                           */
/* Pri 1 Algorithms                                                          */
/*                                                                           */
/*****************************************************************************/

/*
int main(){
  return 0;
}
*/