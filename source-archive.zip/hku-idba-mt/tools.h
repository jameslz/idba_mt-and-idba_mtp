#ifndef TOOLS_H
#define TOOLS_H

#include "libheader.h"

class Tools {
public:
  Tools();					//constructor
  ~Tools();					//destructor
  
/*****************************************************************************/
/*                                                                           */
/* Pub 1 Access Attributes                                                   */
/*                                                                           */
/*****************************************************************************/
  
/*****************************************************************************/
/*                                                                           */
/* Pub 2 Algorithms                                                          */
/*                                                                           */
/*****************************************************************************/

//basic statistic
static long double choose(const long n, const long r); 

//convert an integer to a string
static string intToStr(int i);

//Hamming distance
static int hamDist(const char* s1, const char* s2, const int testLength);
static int hamDistR(const char* s1, const char* s2, const int testLength);

static int hamDist_shift(const char* s1, const char* s2, const int testLength
                         , const int max_shift);
                         
//Other distance
static int matchChar(const char* s1, const char* s2, const int l1, const int l2);

                         
//hash table related
static void combination(long* combinationArr, const long comArrSize, const long comArrPos
                        , const long m, vector<long*> &comArrVec);
static void longToPattern(char* pattern, const long patternLength
                          , const unsigned long number);
static unsigned long patternToLong(const char* pattern, const long patternLength);
                        	
/*****************************************************************************/
/*                                                                           */
/* Pub 3 Parameters                                                          */
/*                                                                           */
/*****************************************************************************/  
  
private:
/*****************************************************************************/
/*                                                                           */
/* Pri 1 Algorithms                                                          */
/*                                                                           */
/*****************************************************************************/
  
/*****************************************************************************/
/*                                                                           */
/* Pri 2 Parameters                                                          */
/*                                                                           */
/*****************************************************************************/
};

#endif

