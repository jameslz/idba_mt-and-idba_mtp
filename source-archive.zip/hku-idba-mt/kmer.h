#ifndef KMER_H
#define KMER_H
#include "libheader.h"
#include "contig.h"

class KMer {
public:
  KMer(KMer *next, uint64_t pattern_code, int k_value);	//constructor
  KMer(KMer *next, const char* pattern, int k_value);	//constructor
  ~KMer();					//destructor
  
/*****************************************************************************/
/*                                                                           */
/* Pub 1 Access Attributes                                                   */
/*                                                                           */
/*****************************************************************************/

  //get pattern
  uint64_t getPatCode();
  uint64_t getPatCodeR(int k_value);
  
  //get DNA
  void getDNA(char* dna, int k_value);
  void getDNAR(char* dna, int k_value);
     
  
  //set Next K mer
  void setNext(uint64_t code, char nuclecide, bool is_exist);
  void setNext(uint64_t code, int nucl_int, bool is_exist);
  void setPrev(uint64_t code, char nuclecide, bool is_exist);
  void setPrev(uint64_t code, int nucl_int, bool is_exist);
  
  //check if next K mer exist
  bool checkNext(uint64_t code, char nuclecide);
  bool checkNext(uint64_t code, int nucl_int);
  bool checkPrev(uint64_t code, char nuclecide);
  bool checkPrev(uint64_t code, int nucl_int);
  
  //get count
  unsigned short getCount();
  //add count
  unsigned short addCount(unsigned short add_value);
  
  //get Next
  KMer* getNextKmer();
  //set Next
  void setNextKmer(KMer* next_kmer);
  
  //get Adj arr
  bitset<8> getAdjArr();
  
  //check if in single path
  bool isSingleNext(uint64_t code);
  bool isSinglePrev(uint64_t code);
  
  int getOutDeg(uint64_t code);
  int getInDeg(uint64_t code);
  
  //get corresponding contig
  Contig* getContig();
  int setContig(Contig* contig);
  
/*****************************************************************************/
/*                                                                           */
/* Pub 2 Algorithms                                                          */
/*                                                                           */
/*****************************************************************************/

  //get Next K mer
  static uint64_t getNext(uint64_t code, char nuclecide, int k_value);
  static uint64_t getNext(uint64_t code, int nucl_int, int k_value);
  
  static uint64_t getPrev(uint64_t code, char nuclecide, int k_value);
  static uint64_t getPrev(uint64_t code, int nucl_int, int k_value);
  
  static uint64_t reverseComplement(uint64_t pattern, int k_value);
  static uint64_t PattoCode(const char* pattern, int k_value);
/*****************************************************************************/
/*                                                                           */
/* Pub 3 Parameters                                                          */
/*                                                                           */
/*****************************************************************************/  
  
private:
/*****************************************************************************/
/*                                                                           */
/* Pri 1 Algorithms                                                          */
/*                                                                           */
/*****************************************************************************/
  

  
/*****************************************************************************/
/*                                                                           */
/* Pri 2 Parameters                                                          */
/*                                                                           */
/*****************************************************************************/
  uint64_t pattern_code;
  KMer* next;
  bitset<8> adj_nucl_arr; //Prev ACGT NEXT ACGT
  unsigned short count;
  Contig* contig;
};

#endif

