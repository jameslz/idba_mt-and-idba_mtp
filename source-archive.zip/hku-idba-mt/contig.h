#ifndef CONTIG_H
#define CONTIG_H
#include "libheader.h"

class Contig {
public:
  Contig();	//constructor
  ~Contig();					//destructor
  
/*****************************************************************************/
/*                                                                           */
/* Pub 1 Access Attributes                                                   */
/*                                                                           */
/*****************************************************************************/

  //get sequence
  const char* getSeq();
  
  //get DNA sequence length
  int getSeqLength();
  
  //set pattern
  int setSeq(const char* pattern);
  
  //getCode
  //uint64_t getStartCode();
  //uint64_t getStartCodeR();
  //uint64_t getEndCode();
  //uint64_t getEndCodeR();
  
  //add neighbor read
  int addNeigRead(int read_no);
  
  vector<int>* getNeigVec();
/*****************************************************************************/
/*                                                                           */
/* Pub 2 Algorithms                                                          */
/*                                                                           */
/*****************************************************************************/

/*
  //get Next K mer
  static uint64_t getNext(uint64_t code, char nuclecide, int k_value);
  static uint64_t getNext(uint64_t code, int nucl_int, int k_value);
  
  static uint64_t getPrev(uint64_t code, char nuclecide, int k_value);
  static uint64_t getPrev(uint64_t code, int nucl_int, int k_value);
  
  static uint64_t reverseComplement(uint64_t pattern, int k_value);
*/
/*****************************************************************************/
/*                                                                           */
/* Pub 3 Parameters                                                          */
/*                                                                           */
/*****************************************************************************/  
  
private:
/*****************************************************************************/
/*                                                                           */
/* Pri 1 Algorithms                                                          */
/*                                                                           */
/*****************************************************************************/
  

  
/*****************************************************************************/
/*                                                                           */
/* Pri 2 Parameters                                                          */
/*                                                                           */
/*****************************************************************************/
  const char* pattern;
  int contig_len;
  uint64_t start_code;
  uint64_t start_codeR;
  uint64_t end_code;
  uint64_t end_codeR;
  vector<int> local_read_vec;
};

#endif

