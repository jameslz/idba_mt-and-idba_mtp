#ifndef LIBHEADER_H
#define LIBHEADER_H

#include <algorithm>
#include <bitset>
#include <dirent.h>
#include <errno.h>
#include <float.h>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits.h>
#include <math.h>
#include <sstream>
#include <stdlib.h>
#include <stdio.h>
#include <string>
#include <string.h>
#include <sys/types.h>
#include <time.h>
#include <vector>

using namespace std;

#endif

