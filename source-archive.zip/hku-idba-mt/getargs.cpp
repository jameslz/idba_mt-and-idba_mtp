#include "getargs.h"

/*****************************************************************************/
/*                                                                           */
/* Constructor and Destructor                                                */
/*                                                                           */
/*****************************************************************************/

Getargs::Getargs(int argc, const char** argv				//constructor
                 , ParaFormat* _para_format, int format_no):
  para_format(_para_format),
  para_size(format_no)
{			
  prog_name=new char[strlen(argv[0])+1];
  strcpy(prog_name,argv[0]);
  is_error=false;
  
  para_vec.clear();
  
  int count=1;
  while(count < argc && !is_error){
    const char* para_symbol=argv[count];
    if(para_symbol[0]!='-'){
      is_error=true;
      break;
    }
    
    bool is_find=false;
    for(int i=0;i<format_no;i++){
      if(strcmp(&para_symbol[1],para_format[i].symbol)==0){
        is_find=true;
        
        for(int j=0;j<(int)para_vec.size();j++){
          if(para_vec.at(j)->getIndex() == para_format[i].index){
            is_error=true;
            break;
          }
        }
        
        
        if(para_format[i].arg_no==1){
          count++;
          if(count < argc){
            if(para_format[i].arg_type == 'd'){
              int temp_int=atoi(argv[count]);
              if(temp_int==0 && (argv[count][0] != '0' || strlen(argv[count])!=1)){
                is_error=true;
                break;
              } else{
                para_vec.push_back(new ParaVal(para_format[i].index,NULL,temp_int));
              }
            } else {
              char* temp_str=new char[strlen(argv[count])+1];
              strcpy(temp_str,argv[count]);
              para_vec.push_back(new ParaVal(para_format[i].index,temp_str,1));            
            }
          }
          else{
            is_error=true;
            break;
          }
        } else {
          para_vec.push_back(new ParaVal(para_format[i].index,NULL,1));
        }
      }
    }
    if(is_find==false){
      is_error=true;
      break;
    }
    count++;
  }
}


Getargs::~Getargs(){			//destructor
  //cout<<"destructor in Getargs"<<endl;
  
  for(int i=0;i<(int)para_vec.size();i++)
    delete para_vec.at(i);
  if(prog_name!=NULL)
    delete[] prog_name;
}	

/*****************************************************************************/
/*                                                                           */
/* Pub 1 Access Attributes                                                   */
/*                                                                           */
/*****************************************************************************/

bool Getargs::isError(){
  return is_error;
}

unsigned int Getargs::getParaValSize(){
  return para_vec.size();
}

ParaVal* Getargs::getPara(int i){
  return para_vec.at(i);
}

/*****************************************************************************/
/*                                                                           */
/* Pub 2 Algorithms                                                          */
/*                                                                           */
/*****************************************************************************/

void Getargs::print_list (ostream &os){
  os << "Usage : " << prog_name << " [-" << para_format[0].symbol;
  for(int i=1;i<para_size;i++)
    os << "/" << para_format[i].symbol;
  os << "]" << endl;
  os << endl;
  for(int i=0;i<para_size;i++){
    os << "-" << para_format[i].symbol << "\t"
       << para_format[i].name << "\t" << para_format[i].desc <<endl;
  }
  os <<endl;
}
/*****************************************************************************/
/*                                                                           */
/* Pri 1 Algorithms                                                          */
/*                                                                           */
/*****************************************************************************/
